// import { Navigation } from '../components/Navigation'
import { GoogleLogin } from '@react-oauth/google';
import {Login2} from './Screens/Auth/Login2';
import {Login} from './Screens/Auth/Login';

function App() {
//   const responseMessage = (response) => {
//     console.log(response);

// };
// const errorMessage = (error) => {
//     console.log(error);
// };
  return (
    // <Navigation/>
    <Login/>
  );
}

export default App;
